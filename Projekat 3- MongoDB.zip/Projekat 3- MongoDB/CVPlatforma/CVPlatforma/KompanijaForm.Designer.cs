﻿namespace CVPlatforma
{
    partial class KompanijaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dodaj_konkurs = new System.Windows.Forms.Button();
            this.pretrazi_konkurse = new System.Windows.Forms.Button();
            this.prikazi_profil = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Pocetak = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Tip = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.radnoMesto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Opis = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Obrazovanje = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Zahtevi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.idKonkursa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.idKompanije = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.obrisi_konkurs = new System.Windows.Forms.Button();
            this.prikazi_civije = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.ime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.datumRodjenja = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.adresa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.telefon = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cv_obrazovanje = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.vestine_cv = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dodaj_konkurs
            // 
            this.dodaj_konkurs.BackColor = System.Drawing.SystemColors.HotTrack;
            this.dodaj_konkurs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dodaj_konkurs.Location = new System.Drawing.Point(861, 94);
            this.dodaj_konkurs.Name = "dodaj_konkurs";
            this.dodaj_konkurs.Size = new System.Drawing.Size(114, 63);
            this.dodaj_konkurs.TabIndex = 0;
            this.dodaj_konkurs.Text = "Dodaj konkurs";
            this.dodaj_konkurs.UseVisualStyleBackColor = false;
            this.dodaj_konkurs.Click += new System.EventHandler(this.dodaj_konkurs_Click);
            // 
            // pretrazi_konkurse
            // 
            this.pretrazi_konkurse.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pretrazi_konkurse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pretrazi_konkurse.Location = new System.Drawing.Point(861, 178);
            this.pretrazi_konkurse.Name = "pretrazi_konkurse";
            this.pretrazi_konkurse.Size = new System.Drawing.Size(114, 64);
            this.pretrazi_konkurse.TabIndex = 1;
            this.pretrazi_konkurse.Text = "Pretrazi konkurse";
            this.pretrazi_konkurse.UseVisualStyleBackColor = false;
            this.pretrazi_konkurse.Click += new System.EventHandler(this.pretrazi_konkurse_Click);
            // 
            // prikazi_profil
            // 
            this.prikazi_profil.BackColor = System.Drawing.SystemColors.HotTrack;
            this.prikazi_profil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prikazi_profil.Location = new System.Drawing.Point(861, 22);
            this.prikazi_profil.Name = "prikazi_profil";
            this.prikazi_profil.Size = new System.Drawing.Size(111, 59);
            this.prikazi_profil.TabIndex = 2;
            this.prikazi_profil.Text = "Prikazi profil";
            this.prikazi_profil.UseVisualStyleBackColor = false;
            this.prikazi_profil.Click += new System.EventHandler(this.prikazi_profil_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Pocetak,
            this.Tip,
            this.radnoMesto,
            this.Opis,
            this.Obrazovanje,
            this.Zahtevi,
            this.idKonkursa,
            this.idKompanije});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(12, 22);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(791, 246);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // Pocetak
            // 
            this.Pocetak.Text = "Pocetak";
            this.Pocetak.Width = 111;
            // 
            // Tip
            // 
            this.Tip.Text = "Tip";
            this.Tip.Width = 88;
            // 
            // radnoMesto
            // 
            this.radnoMesto.Text = "Radno mesto";
            this.radnoMesto.Width = 135;
            // 
            // Opis
            // 
            this.Opis.Text = "Opis";
            this.Opis.Width = 119;
            // 
            // Obrazovanje
            // 
            this.Obrazovanje.Text = "Obrazovanje";
            this.Obrazovanje.Width = 162;
            // 
            // Zahtevi
            // 
            this.Zahtevi.Text = "Zahtevi";
            this.Zahtevi.Width = 207;
            // 
            // idKonkursa
            // 
            this.idKonkursa.Text = "idKonkursa";
            this.idKonkursa.Width = 0;
            // 
            // idKompanije
            // 
            this.idKompanije.Text = "idKompanije";
            this.idKompanije.Width = 0;
            // 
            // obrisi_konkurs
            // 
            this.obrisi_konkurs.BackColor = System.Drawing.SystemColors.HotTrack;
            this.obrisi_konkurs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.obrisi_konkurs.Location = new System.Drawing.Point(861, 259);
            this.obrisi_konkurs.Name = "obrisi_konkurs";
            this.obrisi_konkurs.Size = new System.Drawing.Size(114, 64);
            this.obrisi_konkurs.TabIndex = 4;
            this.obrisi_konkurs.Text = "Obrisi konkurs";
            this.obrisi_konkurs.UseVisualStyleBackColor = false;
            this.obrisi_konkurs.Click += new System.EventHandler(this.obrisi_konkurs_Click);
            // 
            // prikazi_civije
            // 
            this.prikazi_civije.BackColor = System.Drawing.SystemColors.HotTrack;
            this.prikazi_civije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prikazi_civije.Location = new System.Drawing.Point(864, 422);
            this.prikazi_civije.Name = "prikazi_civije";
            this.prikazi_civije.Size = new System.Drawing.Size(111, 63);
            this.prikazi_civije.TabIndex = 5;
            this.prikazi_civije.Text = "Prikazi CV-ije";
            this.prikazi_civije.UseVisualStyleBackColor = false;
            this.prikazi_civije.Click += new System.EventHandler(this.prikazi_civije_Click);
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ime,
            this.datumRodjenja,
            this.adresa,
            this.email,
            this.telefon,
            this.cv_obrazovanje,
            this.vestine_cv});
            this.listView2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(12, 292);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(791, 226);
            this.listView2.TabIndex = 6;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // ime
            // 
            this.ime.Text = "Puno ime";
            this.ime.Width = 113;
            // 
            // datumRodjenja
            // 
            this.datumRodjenja.Text = "Datum rodjenja";
            this.datumRodjenja.Width = 139;
            // 
            // adresa
            // 
            this.adresa.Text = "Adresa";
            this.adresa.Width = 88;
            // 
            // email
            // 
            this.email.Text = "Email";
            this.email.Width = 100;
            // 
            // telefon
            // 
            this.telefon.Text = "Telefon";
            this.telefon.Width = 91;
            // 
            // cv_obrazovanje
            // 
            this.cv_obrazovanje.Text = "Obrazovanje";
            this.cv_obrazovanje.Width = 140;
            // 
            // vestine_cv
            // 
            this.vestine_cv.Text = "Vestine";
            this.vestine_cv.Width = 101;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(828, 367);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 40);
            this.label1.TabIndex = 7;
            this.label1.Text = "Odaberite konkurs za koji \r\nzelite da prikazete cv-ijeve";
            // 
            // KompanijaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1032, 544);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.prikazi_civije);
            this.Controls.Add(this.obrisi_konkurs);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.prikazi_profil);
            this.Controls.Add(this.pretrazi_konkurse);
            this.Controls.Add(this.dodaj_konkurs);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "KompanijaForm";
            this.Text = "KompanijaForm";
            this.Load += new System.EventHandler(this.KompanijaForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button dodaj_konkurs;
        private System.Windows.Forms.Button pretrazi_konkurse;
        private System.Windows.Forms.Button prikazi_profil;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button obrisi_konkurs;
        private System.Windows.Forms.Button prikazi_civije;
        private System.Windows.Forms.ColumnHeader Pocetak;
        private System.Windows.Forms.ColumnHeader Tip;
        private System.Windows.Forms.ColumnHeader radnoMesto;
        private System.Windows.Forms.ColumnHeader Opis;
        private System.Windows.Forms.ColumnHeader Obrazovanje;
        private System.Windows.Forms.ColumnHeader Zahtevi;
        private System.Windows.Forms.ColumnHeader idKonkursa;
        private System.Windows.Forms.ColumnHeader idKompanije;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader ime;
        private System.Windows.Forms.ColumnHeader datumRodjenja;
        private System.Windows.Forms.ColumnHeader adresa;
        private System.Windows.Forms.ColumnHeader email;
        private System.Windows.Forms.ColumnHeader telefon;
        private System.Windows.Forms.ColumnHeader cv_obrazovanje;
        private System.Windows.Forms.ColumnHeader vestine_cv;
        private System.Windows.Forms.Label label1;
    }
}