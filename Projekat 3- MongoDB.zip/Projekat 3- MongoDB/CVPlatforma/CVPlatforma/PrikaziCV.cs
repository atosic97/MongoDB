﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CVPlatforma
{
    public partial class PrikaziCV : Form
    {
        public MongoClient client;
        public Student student;

        public PrikaziCV()
        {
            InitializeComponent();
            MongoClient client = new MongoClient("mongodb://localhost:27017");
        }

        private void PrikaziCV_Load(object sender, EventArgs e)
        {
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Student>("student");
            var collection1 = db.GetCollection<CV>("cv");
            var filter = Builders<Student>.Filter.Eq("korisnickoIme", student.korisnickoIme);
            var result = collection.Find(filter).ToList();
         
            if (result.Count != 0)
            {
                var filter1 = Builders<CV>.Filter.Eq("studentId", result[0]._id);
                var result1 = collection1.Find(filter1).ToList();
                if (result1.Count != 0)
                {
                    txtPunoIme.Text = result1[0].licneInformacije.punoIme;
                    txtDatumRodj.Text = result1[0].licneInformacije.datumRodjenja;
                    txtAdresa.Text = result1[0].licneInformacije.adresa;
                    txtEmail.Text = result1[0].licneInformacije.email;
                    txtTelefon.Text = result1[0].licneInformacije.telefon;
                    string[] values = result1[0].obrazovanje;
                    string val = "";
                    
                    for (int i =0; i<values.Length; i++ )
                    {
                        if (i == values.Length-1)
                        {
                            val += "" + values[i];
                        }
                        else
                        {
                            val += "" + values[i] + ",";
                        }
                    }
                    txtObrazovanje.Text = val;
                    string[] values1 = result1[0].vestine;
                    string val1 = "";
                   
                    for (int i = 0; i < values1.Length; i++)
                    {
                        if (i == values1.Length-1)
                        {
                            val1 += "" + values1[i];
                        }
                        else
                        {
                            val1 += "" + values1[i] + ",";
                        }
                    }
                    txtVestine.Text= val1;
                }
                else
                {
                    MessageBox.Show("Nemate CV");
                    this.Close();
                }
            }
        }

        private void IzmeniCV_Click(object sender, EventArgs e)
        {
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Student>("student");
            var collection1 = db.GetCollection<CV>("cv");
            var filter = Builders<Student>.Filter.Eq("korisnickoIme", student.korisnickoIme);
            var result = collection.Find(filter).ToList();
           
            string[] obrazovanje = txtObrazovanje.Text.Split(',');
            string[] vestine = txtVestine.Text.Split(',');

            if (result.Count != 0)
            {
                var filter1 = Builders<CV>.Filter.Eq("studentId", result[0]._id);
                var result1 = collection1.Find(filter1).ToList();

                var cv = new CV(result1[0]._id, result[0]._id, txtPunoIme.Text, txtDatumRodj.Text, txtAdresa.Text,txtEmail.Text,txtTelefon.Text, obrazovanje, vestine);
                var update = new BsonDocument { { "$set", cv.ToBsonDocument() } };
                collection1.UpdateOne(filter1, update);
                MessageBox.Show("Uspesno ste izmenili CV");
                //Update();
            }
        }
    }
}
