﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CVPlatforma
{
    public class Student
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public string imePrezime { get; set; }
        public string korisnickoIme { get; set; }
        public string sifra { get; set; }
        public string email { get; set; }

       /* public Student()
        {
            //this._id = ObjectId;
            //this.imePrezime = "";
            //this.korisnickoIme = "";
            //this.email = "";
            //this.sifra = "";

        }*/
        public Student(string _id, string imePrezime, string korisnickoIme, string sifra, string email)
        {
            this._id = _id;
            this.imePrezime = imePrezime;
            this.korisnickoIme = korisnickoIme;
            this.email = email;
            this.sifra = sifra;
        }
        
    }
}
