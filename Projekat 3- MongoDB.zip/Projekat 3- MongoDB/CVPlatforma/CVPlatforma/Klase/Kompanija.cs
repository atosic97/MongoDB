﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CVPlatforma
{
    public class Kompanija
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public string ime { get; set; }
        public string adresa { get; set; }
        public string telefon { get; set; }
        public string email { get; set; }
        public string sifra { get; set; }

        public Kompanija()
        {
            //this._id = "";
            //this.ime = "";
            //this.adresa = "";
            //this.telefon = "";
            //this.email = "";
            //this.sifra = "";

        }
        public Kompanija(string _id, string ime, string adresa, string telefon, string email, string sifra)
        {
            this._id = _id;
            this.ime = ime;
            this.adresa = adresa;
            this.telefon = telefon;
            this.email = email;
            this.sifra =sifra ;
        }
      
    }
}
