﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;


namespace CVPlatforma
{
    public partial class RegistracijaKompanija : Form
    {
        
        public RegistracijaKompanija()
        {
            InitializeComponent();
            MongoClient client = new MongoClient("mongodb://localhost:27017");
            textBoxSifra.UseSystemPasswordChar = true;
        }

        private void registracija_Click(object sender, EventArgs e)
        {
            string _id = ObjectId.GenerateNewId().ToString();
            string ime = textBoxIme.Text;
            string adresa = textBoxAdresa.Text;
            string telefon = textBoxTelefon.Text;
            string email = textBoxEmail.Text;
            string sifra = textBoxSifra.Text;

            MongoClient client = new MongoClient();
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<BsonDocument>("kompanija");
            Kompanija k = new Kompanija(_id,ime,adresa,telefon,email,sifra);
            var filter = Builders<BsonDocument>.Filter.Eq("email", email);
            var result = collection.Find(filter).ToList();
            if (result.Count != 0)
            {
                MessageBox.Show("Nemoguca registracija sa zadatim emailom");
            }
            else
            {
                collection.InsertOne(k.ToBsonDocument());
                MessageBox.Show("Uspesno ste se registrivali");
                KompanijaForm komp = new KompanijaForm();
                komp.client = client;
                komp.kompanija = k;
                komp.Show();
               // this.Close();

            }

                


        }

        private void textBoxIme_TextChanged(object sender, EventArgs e)
        {

        }

        private void RegistracijaKompanija_Load(object sender, EventArgs e)
        {
            MongoClient client = new MongoClient();
            var db = client.GetDatabase("posao");
            if (db == null)
            {
                MessageBox.Show("Greska prilikom konekcije");
            }
        }
    }
}
