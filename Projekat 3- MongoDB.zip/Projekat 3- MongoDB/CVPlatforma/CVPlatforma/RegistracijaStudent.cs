﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CVPlatforma
{
    public partial class RegistracijaStudent : Form
    {
       
        public RegistracijaStudent()
        {
            InitializeComponent();
            textBoxSifra.UseSystemPasswordChar = true;
        }

        //registracija studenta 
        private void button1_Click(object sender, EventArgs e)
        {
            string id = ObjectId.GenerateNewId().ToString();
            string imePrezime = textBoxImeIPrezime.Text;
            string korisnickoIme = textBoxKorisnickoIme.Text;
            string email = textBoxEmail.Text;
            string sifra = textBoxSifra.Text;

            MongoClient client = new MongoClient();
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Student>("student");
            Student s = new Student(id, imePrezime, korisnickoIme, sifra, email);
            var filter = Builders<Student>.Filter.Eq("korisnickoIme", korisnickoIme);
            var result = collection.Find(filter).ToList();
            if (result.Count != 0)
            {
                MessageBox.Show("Nemoguca registracija zadati email je zauzet");
            }
            else
            {
                collection.InsertOne(s);
                MessageBox.Show("Uspesno ste se registrivali");
                StudentForm st = new StudentForm();
                st.student = s;
                st.client = client;
                st.Show();
               // this.Close();
            }
        }

        private void RegistracijaStudent_Load(object sender, EventArgs e)
        {
            //MongoClient client = new MongoClient();
            //var db = client.GetDatabase("posao");
            //if (db == null)
            //{
            //    MessageBox.Show("Greska prilikom konekcije");
            //}
        }
    }
}
