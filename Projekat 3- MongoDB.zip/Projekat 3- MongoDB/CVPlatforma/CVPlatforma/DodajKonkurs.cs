﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;

namespace CVPlatforma
{
    public partial class DodajKonkurs : Form
    {
         public Kompanija kompanija;
         public MongoClient client;

        public DodajKonkurs()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dodaj_konkurs_Click(object sender, EventArgs e)
        {
            string pocetak = textBoxPocetakKonkursa.Text;
            string tip = textBoxTip.Text.ToUpper();
            string radnoMesto = textBoxRadnoMesto.Text;
            string opis = textBoxOpis.Text;
            string obrazovanje = textBoxObrazovanje.Text;
            string zahtevi = textBoxZahtevi.Text;

            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Konkurs>("konkurs");
            var collection1 = db.GetCollection<Kompanija>("kompanija");
            var filter = Builders<Kompanija>.Filter.Eq("email", kompanija.email);
            var result = collection1.Find(filter).ToList();
            if(result.Count!=0)
            {
                string id = ObjectId.GenerateNewId().ToString();

                Konkurs konkurs = new Konkurs(id, result[0]._id, pocetak, tip, radnoMesto, opis, obrazovanje, zahtevi);
                collection.InsertOne(konkurs);
                MessageBox.Show("Uspesno ste dodali konkurs.");
            }
            
            
        }
    }
}
