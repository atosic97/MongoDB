﻿namespace CVPlatforma
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prikazi_konkurse = new System.Windows.Forms.Button();
            this.prikazi_profil = new System.Windows.Forms.Button();
            this.prijava = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Pocetak = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Tip = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.radnoMesto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Opis = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Obrazovanje = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Zahtev = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.idKonkursa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // prikazi_konkurse
            // 
            this.prikazi_konkurse.BackColor = System.Drawing.SystemColors.HotTrack;
            this.prikazi_konkurse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prikazi_konkurse.Location = new System.Drawing.Point(188, 124);
            this.prikazi_konkurse.Name = "prikazi_konkurse";
            this.prikazi_konkurse.Size = new System.Drawing.Size(155, 54);
            this.prikazi_konkurse.TabIndex = 0;
            this.prikazi_konkurse.Text = "Prikazi konkurse";
            this.prikazi_konkurse.UseVisualStyleBackColor = false;
            this.prikazi_konkurse.Click += new System.EventHandler(this.prikazi_konkurse_Click);
            // 
            // prikazi_profil
            // 
            this.prikazi_profil.BackColor = System.Drawing.SystemColors.HotTrack;
            this.prikazi_profil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prikazi_profil.Location = new System.Drawing.Point(826, 62);
            this.prikazi_profil.Name = "prikazi_profil";
            this.prikazi_profil.Size = new System.Drawing.Size(136, 54);
            this.prikazi_profil.TabIndex = 1;
            this.prikazi_profil.Text = "Prikazi profil";
            this.prikazi_profil.UseVisualStyleBackColor = false;
            this.prikazi_profil.Click += new System.EventHandler(this.prikazi_profil_Click);
            // 
            // prijava
            // 
            this.prijava.BackColor = System.Drawing.SystemColors.HotTrack;
            this.prijava.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijava.Location = new System.Drawing.Point(826, 325);
            this.prijava.Name = "prijava";
            this.prijava.Size = new System.Drawing.Size(138, 54);
            this.prijava.TabIndex = 4;
            this.prijava.Text = "Prijavi se na konkurs";
            this.prijava.UseVisualStyleBackColor = false;
            this.prijava.Click += new System.EventHandler(this.prijava_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "PRAKSA",
            "POSAO NA ODREDJENO",
            "POSAO NA NEODREDJENO",
            "SVI KONKURSI"});
            this.comboBox1.Location = new System.Drawing.Point(165, 79);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(205, 26);
            this.comboBox1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(138, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(435, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Odaberite tip konkursa po kom zelite da izvrsite pretragu:";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Pocetak,
            this.Tip,
            this.radnoMesto,
            this.Opis,
            this.Obrazovanje,
            this.Zahtev,
            this.idKonkursa});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(45, 208);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(759, 263);
            this.listView1.TabIndex = 8;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // Pocetak
            // 
            this.Pocetak.Text = "Pocetak";
            this.Pocetak.Width = 111;
            // 
            // Tip
            // 
            this.Tip.Text = "Tip";
            this.Tip.Width = 85;
            // 
            // radnoMesto
            // 
            this.radnoMesto.Text = "Radno Mesto";
            this.radnoMesto.Width = 135;
            // 
            // Opis
            // 
            this.Opis.Text = "Opis";
            this.Opis.Width = 127;
            // 
            // Obrazovanje
            // 
            this.Obrazovanje.Text = "Obrazovanje";
            this.Obrazovanje.Width = 116;
            // 
            // Zahtev
            // 
            this.Zahtev.Text = "Zahtevi";
            this.Zahtev.Width = 129;
            // 
            // idKonkursa
            // 
            this.idKonkursa.Text = "idKonkursa";
            this.idKonkursa.Width = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(810, 274);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 40);
            this.label2.TabIndex = 9;
            this.label2.Text = "Odaberite konkurs na koji \r\nželite da se prijavite";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1007, 506);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.prijava);
            this.Controls.Add(this.prikazi_profil);
            this.Controls.Add(this.prikazi_konkurse);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "StudentForm";
            this.Text = "StudentForm";
            this.Load += new System.EventHandler(this.StudentForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button prikazi_konkurse;
        private System.Windows.Forms.Button prikazi_profil;
        private System.Windows.Forms.Button prijava;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Pocetak;
        private System.Windows.Forms.ColumnHeader Tip;
        private System.Windows.Forms.ColumnHeader radnoMesto;
        private System.Windows.Forms.ColumnHeader Opis;
        private System.Windows.Forms.ColumnHeader Obrazovanje;
        private System.Windows.Forms.ColumnHeader Zahtev;
        private System.Windows.Forms.ColumnHeader idKonkursa;
        private System.Windows.Forms.Label label2;
    }
}