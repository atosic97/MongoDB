﻿namespace CVPlatforma
{
    partial class PrikazProfilaStudenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IzmeniProfil = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSifra = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtKorisnicko = new System.Windows.Forms.TextBox();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.dodajCV = new System.Windows.Forms.Button();
            this.prikaziCV = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // IzmeniProfil
            // 
            this.IzmeniProfil.BackColor = System.Drawing.SystemColors.HotTrack;
            this.IzmeniProfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IzmeniProfil.Location = new System.Drawing.Point(104, 289);
            this.IzmeniProfil.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.IzmeniProfil.Name = "IzmeniProfil";
            this.IzmeniProfil.Size = new System.Drawing.Size(134, 46);
            this.IzmeniProfil.TabIndex = 0;
            this.IzmeniProfil.Text = "Izmeni profil";
            this.IzmeniProfil.UseVisualStyleBackColor = false;
            this.IzmeniProfil.Click += new System.EventHandler(this.IzmeniProfil_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ime i prezime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 84);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Korisnicko ime:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 129);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Email:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 174);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Sifra:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSifra);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtKorisnicko);
            this.groupBox1.Controls.Add(this.txtIme);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(22, 31);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(266, 239);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Licni podaci";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtSifra
            // 
            this.txtSifra.Location = new System.Drawing.Point(130, 171);
            this.txtSifra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtSifra.Name = "txtSifra";
            this.txtSifra.Size = new System.Drawing.Size(125, 23);
            this.txtSifra.TabIndex = 8;
            this.txtSifra.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(130, 124);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(125, 23);
            this.txtEmail.TabIndex = 7;
            // 
            // txtKorisnicko
            // 
            this.txtKorisnicko.Location = new System.Drawing.Point(130, 81);
            this.txtKorisnicko.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtKorisnicko.Name = "txtKorisnicko";
            this.txtKorisnicko.Size = new System.Drawing.Size(125, 23);
            this.txtKorisnicko.TabIndex = 6;
            // 
            // txtIme
            // 
            this.txtIme.Location = new System.Drawing.Point(130, 38);
            this.txtIme.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(125, 23);
            this.txtIme.TabIndex = 5;
            // 
            // dodajCV
            // 
            this.dodajCV.BackColor = System.Drawing.SystemColors.HotTrack;
            this.dodajCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dodajCV.Location = new System.Drawing.Point(326, 82);
            this.dodajCV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dodajCV.Name = "dodajCV";
            this.dodajCV.Size = new System.Drawing.Size(117, 48);
            this.dodajCV.TabIndex = 6;
            this.dodajCV.Text = "Dodaj CV";
            this.dodajCV.UseVisualStyleBackColor = false;
            this.dodajCV.Click += new System.EventHandler(this.dodajCV_Click);
            // 
            // prikaziCV
            // 
            this.prikaziCV.BackColor = System.Drawing.SystemColors.HotTrack;
            this.prikaziCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prikaziCV.Location = new System.Drawing.Point(326, 160);
            this.prikaziCV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prikaziCV.Name = "prikaziCV";
            this.prikaziCV.Size = new System.Drawing.Size(117, 50);
            this.prikaziCV.TabIndex = 7;
            this.prikaziCV.Text = "Prikazi CV";
            this.prikaziCV.UseVisualStyleBackColor = false;
            this.prikaziCV.Click += new System.EventHandler(this.prikaziCV_Click);
            // 
            // PrikazProfilaStudenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(487, 367);
            this.Controls.Add(this.prikaziCV);
            this.Controls.Add(this.dodajCV);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.IzmeniProfil);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "PrikazProfilaStudenta";
            this.Text = "PrikazProfilaStudenta";
            this.Load += new System.EventHandler(this.PrikazProfilaStudenta_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button IzmeniProfil;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSifra;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtKorisnicko;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.Button dodajCV;
        private System.Windows.Forms.Button prikaziCV;
    }
}